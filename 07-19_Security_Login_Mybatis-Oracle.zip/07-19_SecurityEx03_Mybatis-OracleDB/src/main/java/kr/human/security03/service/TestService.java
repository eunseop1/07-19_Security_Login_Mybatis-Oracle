package kr.human.security03.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.human.security03.dao.testDAO;

@Service
public class TestService {
	@Autowired
	private testDAO testDAO;
	
	public String selectToday() {
		return testDAO.selectToday();
	}
}
